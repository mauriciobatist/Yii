<?php
/**
 * Created by PhpStorm.
 * User: clawbert
 * Date: 11/07/17
 * Time: 20:40
 */
?>

<div id="proxima-peca"></div>
<div id="tabuleiro"></div>
<div id="informacoes"></div>
<script type="text/javascript" src="../web/js/tetris.js"></script>
