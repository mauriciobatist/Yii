

<div id="proxima-peca"></div>
<div id="tabuleiro"></div>
<div id="informacoes"></div>
<script type="text/javascript" src="../web/js/tetris.js"></script>
